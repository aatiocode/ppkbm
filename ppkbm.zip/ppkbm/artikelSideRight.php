<!-- Start Right Column -->
<div class="col-sm-4">
    <div class="blog-right">
        <div class="category">
            <h3>Kategori</h3>
            <ul>
                <li><a href="#">Lorem Ipsum is simply dummy <span>05</span></a></li>
                <li><a href="#">Ipsum is simply dummy <span>04</span></a></li>
                <li><a href="#">Lorem Ipsum is simply <span>02</span></a></li>
                <li><a href="#">Lorem Ipsum is simply dummy <span>03</span></a></li>
                <li><a href="#">Ipsum is simply dummy <span>02</span></a></li>
            </ul>
        </div>
        <div class="recent-post">
            <h3>Artikel Terbaru</h3>
            <ul>
                <li class="clearfix"> <a href="#">
                        <div class="img-block"><img src="images/rp-thumb1.jpg" class="img-responsive" alt=""></div>
                        <div class="detail">
                            <h4>simply dummy text of the...</h4>
                            <p><span class="icon-date-icon ico"></span><span>14 Feb</span> 2017</p>
                        </div>
                    </a> </li>
                <li class="clearfix"> <a href="#">
                        <div class="img-block"><img src="images/rp-thumb2.jpg" class="img-responsive" alt=""></div>
                        <div class="detail">
                            <h4>simply dummy text of the...</h4>
                            <p><span class="icon-date-icon ico"></span><span>12 Feb</span> 2017</p>
                        </div>
                    </a> </li>
                <li class="clearfix"> <a href="#">
                        <div class="img-block"><img src="images/rp-thumb3.jpg" class="img-responsive" alt=""></div>
                        <div class="detail">
                            <h4>simply dummy text of the...</h4>
                            <p><span class="icon-date-icon ico"></span><span>08 Feb</span> 2017</p>
                        </div>
                    </a> </li>
            </ul>
        </div>
    </div>
</div>
<!-- End Right Column -->